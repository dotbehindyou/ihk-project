
// Deinstallations Methode
// ------------------------
public static Boolean Uninstall(string serviceName)
{
    // .... oeffne SC-Manager(=sCtrlHandler); Siehe Install Methode! ....
    
    int DELETE = 0x10000; // Delete 
    // Öffne den ServiceHandler
    IntPtr serviceHandler = OpenService(sCtrlHandler, serviceName, DELETE);
    if (serviceHandler != IntPtr.Zero)
    { // ServiceHandler konnte geöffnet werden 
        if (DeleteService(serviceHandler) != 0){ //HINWEIS! Der ServiceHandler stoppt automatisch den Dienst, beim deinstallieren!
            // Schließe den SC-Manager 
            CloseServiceHandle(sCtrlHandler);
            return true; // Der Dienst konnte erfolgreich entfernt werden
        }
        else
        {
            // Schließe den SC-Manager
            CloseServiceHandle(sCtrlHandler);
            return false; // Der Dienst konnte NICHT entfernt werden!
        }
    }
    else
        return false;
}